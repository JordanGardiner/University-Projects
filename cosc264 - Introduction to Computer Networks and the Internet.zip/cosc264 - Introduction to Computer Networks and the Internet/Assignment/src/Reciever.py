import socket
from Classes import *
from struct import *
from SupportFunctions import *
import sys, time
import os.path


"""
    Reciever 

"""
HOST = '127.0.0.1'
MAGIC_NUM = 0x497E
        
def main(r_in_port, r_out_port, c_in):
    file_name= 'recieved00.txt'
    ports_list = [(r_in_port), (r_out_port)]

    valid_ports = False

    #validate ports
    for port in ports_list:
        if check_valid_port_num(port):
            valid_ports = True

        else:
            valid_ports = False
            print("Error: Port number must be of tpye integer between 1024 and 64000")
            sys.exit()

    #create and bind sockets to ports
    if valid_ports:
        
        r_in = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        r_out = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        bind_sockets(r_in, r_in_port, HOST)
        bind_sockets(r_out, r_out_port, HOST)

    r_in.listen(5)

    conn, addr = r_in.accept()
    r_out.connect((HOST, c_in))

    #Create outfile
    if not os.path.isfile(file_name):
        file = open(file_name, 'w')
    else:
        #aborts if file already exists
        sys.exit()

    expected = 0

    stop_process = False
    end = False
    
    while not end:       
        stop_process = False
        rcvd = conn.recv(544) #size of data packet + extra Packet variables

        rcvd = un_pack(rcvd)
    
        if not valid_data_packet(rcvd):
            stop_process = True

        if not stop_process and (rcvd.get_seqno() != expected):
            return_packet = Packet(MAGIC_NUM, 1, rcvd.get_seqno(), 0, '', 0)
            return_packet.checkSum = return_packet.make_checkSum()
            return_packet = return_packet.get_packed_packet()
            r_out.send(return_packet)
            stop_porcess = True
        
        elif not stop_process:

            if rcvd.get_dataLength() > 0:
                file.write(rcvd.get_data())
            else:
                file.close()
                break 
            
            return_packet = Packet(MAGIC_NUM, 1, rcvd.get_seqno(), 0, '', 0)
            
            return_packet = return_packet.get_packed_packet()
            r_out.send(return_packet)
            expected += 1            
            
     
    print("closing")
    r_in.close()
    r_out.close()


if __name__ == '__main__':
    r_in, r_out, c_in = inc_port_num("rcv")
    main(r_in, r_out, c_in)
