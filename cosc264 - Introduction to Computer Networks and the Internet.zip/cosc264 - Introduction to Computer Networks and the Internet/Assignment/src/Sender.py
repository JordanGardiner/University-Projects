import socket
import sys, time
import os.path
from SupportFunctions import *
from Classes import Packet
from struct import *
"""
    Sender node

    s_in = sender node inbound socket
    s_out = sender node outbound socket

    Status: Communicating with test client on localhost port 5000
    via s_in


"""

EOF = False
BUFFER_SIZE = 512
HOST = '127.0.0.1'
MAGIC_NUM = 0x497E

def main(s_in_port, s_out_port,c_in):

    #s_in_port = s_in #input("Enter inbound port number: ")
    #s_out_port = s_out#input("Enter outbound port number: ")
    #c_in = c_in #channels in port
    file_name = 'blah.txt'#str(input("Enter file name to send data: "))

    exitFlag = False
    retransmit = True
    valid_ports = False
    packet_count = 0

    ports_list = [(s_in_port), (s_out_port)]
    
    #Validate input file
    if os.path.isfile(file_name):
        print('valid file')
        file = open(file_name)
        pass
    else:
        sys.exit()

    
    #Validate Port Numbers
    for port in ports_list:
        if check_valid_port_num(port):
            valid_ports = True

        else:
            valid_ports = False
            print("Error: Port number must be of tpye integer between 1024 and 64000")
            sys.exit()
            
    #Creae and bind Sockets to ports        
    if valid_ports:

        print('port numbers valid')
        
        s_in = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s_out = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        bind_sockets(s_in, s_in_port, HOST)
        bind_sockets(s_out, s_out_port, HOST)

    #Get input data and create packet
   
    s_out.connect((HOST, c_in))
    s_in.listen(5)
    conn, addr = s_in.accept()        
    next_seqno = 0
        
    while not exitFlag:
        packet_buffer = []
        data = file.read(512)

        
        if data == "":
            out_packet = Packet(MAGIC_NUM, 0, next_seqno, 0, '', 0) 
            print('end now')
            exitFlag = True
        else:
            out_packet = Packet(MAGIC_NUM, 0, next_seqno, len(data), data, 0)

        out_packet.checkSum = out_packet.make_checkSum()
        print("Seqno: " + str(out_packet.seqno) + "  Magicno: " + str(out_packet.magicno) + "  Type: "+ str(out_packet.p_type) + "  data len: " + str(out_packet.dataLen) + "  check " + str(out_packet.checkSum))
        out_packet = out_packet.get_packed_packet()
        packet_buffer.append(out_packet) 
        
        retransmit = True
        i = 0
        while retransmit:

            try:
                send_packet = packet_buffer[0]
                s_out.send(send_packet)
                print(i)
                packet_count += 1
                conn.settimeout(.5)
                rcvd = None
                
                rcvd = conn.recv(BUFFER_SIZE)  
            
                if exitFlag == True:
                    break
                
                if not rcvd:
                    retransmit = True
                    print("not recv")
                else:
                    retransmit = False
                    rcvd_pac = un_pack(rcvd)
                    print("Seqno: " + str(rcvd_pac.seqno) + "  Magicno: " + str(rcvd_pac.magicno) + "  Type: " + str(rcvd_pac.p_type) + "  data len: " + str(rcvd_pac.dataLen))
                    if not valid_reply(rcvd_pac):
                        print('not valid')
                        retransmit = True
                    if rcvd_pac.get_seqno() != next_seqno:
                        print('invalid seqno')
                        retransmit = True    
            except:
                i -= 1
                pass
            
            i += 1
        next_seqno += 1

    if exitFlag == True:
        file.close()

    print("closing")
    print(packet_count)
    s_in.close()
    s_out.close()

    
if __name__ == '__main__':
    s_in, s_out, c_in = inc_port_num("sen")
    main(s_in, s_out, c_in)
    
                
                
