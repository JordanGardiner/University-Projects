"""
    Classes

    p_type:
    
       - 1 for acknowledgement packet
       - 0 for data packet
    
"""
from struct import *


class Packet:
    
    def __init__ (self, magicno, p_type, seqno, dataLen, data, checkSum):

        self.magicno = magicno #int
        self.p_type = p_type #int
        self.seqno = seqno #int
        self.dataLen = dataLen #int
        self.data = data #string
        self.checkSum = checkSum #int
        
    def get_magicno(self):
        """
            returns packet magic number
        """
        return self.magicno
    
    def get_pType(self):
        """
            returns packet type
        """
        return self.p_type
    
    def get_seqno(self):
        """
            returns packet sequence number
        """
        return self.seqno

    def get_dataLength(self):
        """
            returns packet dataLen
        """
        return self.dataLen

    def get_data(self):
        """
            returns contents of packet
        """
        return self.data
    
    def make_checkSum(self):
        self.checkSum = self.dataLen + self.p_type + self.magicno + self.seqno
        return self.checkSum
        
    def get_packed_packet(self):
        ''' packs the values of current packet using structs pack method and 
        returns a byte string '''

        enc_data = self.data.encode('utf-8')
        packet = pack('iiii{}si'.format(self.dataLen), self.magicno, self.p_type,
                      self.seqno, self.dataLen, enc_data, self.checkSum)
        
        return packet
        




#def main():
    #pac = Packet(0, 1, 5, "Hello")
    #packed_packet = pac.get_packed_packet()
    #print(packed_packet)
    #output = un_pack(packed_packet)
    #print(output)
    
    
#main()
