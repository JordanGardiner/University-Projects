import socket
from struct import *
from Classes import Packet
import random
"""
    All support functions
"""


def valid_data_packet(packet):
    """
        Validates data packet
    """

    valid = True

    if packet.get_magicno() != 0x497E:
        valid = False
    if packet.get_pType() != 0:
        valid = False
    if packet.checkSum != packet.make_checkSum():
        valid = False
        
    return valid

def valid_reply(packet):
    """
        Validates response/aknowledgement packet
    """

    valid = True

    if packet.get_magicno() != 0x497E:
        valid = False
    if packet.get_pType() != 1:
        valid = False
    if packet.get_dataLength() != 0:
        valid = False

    return valid


def bind_sockets(s, port, host):
    """
        binds socket to a specified port

    """
    try:
        s.bind((host, port))
        print('socket bound to port: ' + str(port))
    except socket.error as e:
        print(str(e))
                
    

def check_valid_port_num(port):
    """
        checks for valid port numbers of type integer
        between 1024 and 64000
        
    """

    is_valid = True
                
    if port != type(int) or (port < 1024 or port > 64000):
        is_vlaid = False

    return is_valid


def un_pack(packet):
        """
            unpacks encoded packet and returns a packet of Packet type
        """

        string_len = len(packet) - 20 #20 is the number of ints * 4 

        
        pac = unpack('iiii{}si'.format(string_len), packet)

        packet = Packet(pac[0], pac[1], pac[2], pac[3], pac[4].decode('utf-8'), pac[5])

        return packet 
        

def random_float():
    """
        returns random float between 1 and 0
    """
    
    x = random.uniform(0, 1)

    return x

def random_int():
    """
        returns random int between 1 and 10
    """

    x = random.randint(1, 10)

    return x

def inc_port_num(typ):
    file = open("soc.txt")
    n = file.readline()
    n = int(n)
    
    if typ == "chan":
        c_s_out_port = 8000#dont change 
        c_r_out_port = 8001#dont change
        
        c_s_in_port = 5000 #same as sender in
        c_r_in_port = 6000#same as reciever in
         
        s_in_port = 5040 # sendesrs s_in port number
        r_in_port = 6040# recievers r_in port number
        
        return c_s_out_port +n, c_r_out_port+n, c_s_in_port+n, c_r_in_port+n, s_in_port+n, r_in_port+n
    elif typ == "rcv":
        r_in = 6040 #input("Enter inbound port number: ")
        r_out = 5041 #input("Enter outbound port number: ")
        c_in = 6000
        
        return r_in+n, r_out+n, c_in+n
    elif typ == "sen":
        s_in = 5040 #input("Enter inbound port number: ")
        s_out = 5043 #input("Enter outbound port number: ")
        c_in = 5000
        
        return s_in+n, s_out+n, c_in+n