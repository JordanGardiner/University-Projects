import socket
import sys, time
import os.path
import select
from Classes import Packet
from SupportFunctions import *
from struct import *

"""
c_s_in = channels sender in (Port number)
c_s_out = channels sender out (Port number)
c_r_in = channel reciever in (Port number)
c_r_out = channel reciever out (Port number)

s_in = sender in (port number of sender, in which channel sends packets to using
       its own c_s_out) (Port number)
       
r_in = reciever in (Port number of reciever, in which channel sends packets to 
       using its own c_r_out) (Port Number)
       
p_loss_rate = Packet loss rate (value must satisfy 0<P<1) (Fload or double)

"""
HOST = '127.0.0.1'

def main(c_s_in_port, c_s_out_port, c_r_in_port, c_r_out_port, s_in_port, 
         r_in_port, p_loss_rate):
    input_sockets = []
    output_sockets = []
    exception_list = []
    valid_ports = False
    
    ports_list = [(c_s_in_port), (c_s_out_port), (c_r_in_port), (c_r_out_port)]

    #Validate Port Numbers
    for port in ports_list:
        if check_valid_port_num(port):
            valid_ports = True

        else:
            valid_port = False
            print("Error: Port number must be of tpye integer between 1024 and 64000")
            sys.exit()

    #Create and Bind Sockets
    if valid_ports:

        print('port numbers valid')

        #Create
        c_s_in = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        c_s_out = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        c_r_in =  socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        c_r_out =  socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        #Bind
        bind_sockets(c_s_in, c_s_in_port, HOST)
        bind_sockets(c_s_out, c_s_out_port, HOST)
        bind_sockets(c_r_in, c_r_in_port, HOST)
        bind_sockets(c_r_out, c_r_out_port, HOST)
        
    
    c_s_in.listen(5)
    c_r_in.listen(5)
    

    
    #wait for s_in
    conn_sender, addr = c_s_in.accept()
    
    input_sockets.append(conn_sender)
    
    #send to r_out
    c_r_out.connect((HOST, r_in_port))
    output_sockets.append(c_r_out)
    
    #wait for r_in
    conn_reciever, addr = c_r_in.accept()
    input_sockets.append(conn_reciever)
    
    #send to s_out
    c_s_out.connect((HOST, s_in_port))
    output_sockets.append(c_s_out)
    
    
    exitFlag = False
    data = []

    
    exitFlag1 = False
    not_send = False
    
    while not exitFlag:    
        readable, writable, exceptional = select.select(input_sockets, output_sockets, [])
        for s in readable:
            try:
                data.append(s.recv(532)) #size of 512data packet + extra Packet variables
            except:
                break

            packet = (data.pop(0))
            packet = un_pack(packet)
            if packet.dataLen == 0 and packet.get_pType() == 0:
                exitFlag = True
                
            if packet.get_pType() == 0 and packet.dataLen != 0:
                if random_float() < p_loss_rate:
                    not_send = True
                    print("Packet dropped")
                elif random_float() < 0.1:
                    new_length = packet.get_dataLength()
                    new_length += random_int()
                    packet.dataLen = new_length
                    print("Changed data len")


            if not_send == False:
                if packet.get_pType() != 1:
                    packet = packet.get_packed_packet()
                    c_r_out.send(packet)
                else:
                    packet = packet.get_packed_packet()
                    c_s_out.send(packet)

            else:
                not_send = False
                break
            
                
            
        
    print("closing")
    c_r_out.close()
    c_s_out.close()
    c_r_in.close()
    c_r_out.close()
    
if __name__ == '__main__':
    c_s_out_port, c_r_out_port, c_s_in_port, c_r_in_port, s_in_port, r_in_port = inc_port_num("chan")
    main(c_s_in_port, c_s_out_port, c_r_in_port, c_r_out_port, s_in_port, 
         r_in_port, 0.0)
