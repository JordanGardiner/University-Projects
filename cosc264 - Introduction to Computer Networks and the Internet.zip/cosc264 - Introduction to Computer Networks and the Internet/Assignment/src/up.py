import random

infile = open("soc.txt", 'w')
n = random.randint(1,20000)
infile.write(str(n))
