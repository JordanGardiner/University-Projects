#### NOTE #### : This readme is designed for a linux machine. 

** TO Launch and play game **

 - To play the GUI Version of the game, right click on Runme.jar
    and launch with Oracle Java 8 runtime.

    or

    you can run jga99_cgh31_virtual_pet.jar from the terminal.


** To view the source code **
 -  Look in the JAVA FILES folder


** To View the JavaDoc **
  - Open the Javadoc folder and double click on any HTML file


** To runtests **
  - import all non test files into eclipse (including images and JAVA FILES)
  - # note # : if JUnit4 is not in the created project then: 
    import the test files into the src folder.
    Select any of the tests, hover over the red line on the import
    and select the 4th option.
    If you have JUnit4 already in the project than just import the tests into the 
    src folder
  - Either run each test individually or set the run config in eclipse.
  - # Note # : dialog boxes will appear, you need to manually close
    them in order for the tests to finish.


** To load Files into Eclipse **
  - Use all the files from JAVA FILES folder thats provided
  - Import all the Java files into the src folder of a project.
    Then create a folder in src called images # Note # : It's important spelling
    of images is correct and it has a lower case i.
    Then import all the images into the images folder.
    


