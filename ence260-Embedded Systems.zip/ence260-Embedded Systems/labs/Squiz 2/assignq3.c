/* program that takes a filename as first argument and prints the file
 * with the confab encoding
 * Author jga99
 * Date 15/8/17
 */

#include <stdio.h>
#define MAX_LINE_LEN 80

void confab(const char* inText, int shift, char* outText)
{
    /* takes a string and shifts the characters by the specified ammount
     * and copies to a buffer.
     */
    int overflow = 0;
    while(*inText) {
        if (*inText >= 65 && *inText <= 90) {
            //capital Letters
            overflow = *inText + shift;
            overflow = ((overflow-13) %26) + 65;
            *outText = overflow;
        } else if (*inText >= 97 && *inText <= 122) {
            //not capital Letters
            overflow = *inText + shift;
            overflow = ((overflow -19) %26) +97;
            *outText = overflow;
        } else {
            *outText = *inText;
        }
        inText++;
        outText++;
    }
    *outText = '\0';
}

void readAndEncrypt(void)
{
    /* takes a file and encrypts each line with confab
     */
    char encrypted[MAX_LINE_LEN] = {'\0'};
    char buffer[MAX_LINE_LEN] = {'\0'};
    while (fgets(buffer, MAX_LINE_LEN, stdin)) {
        confab(buffer, 13, encrypted);
        printf("%s", encrypted);
    }
}

int main(void)
{
    readAndEncrypt();
}

