#include "system.h"
#include "button.h"
#include "pacer.h"
#include "tinygl.h"
#include "../fonts/font3x5_1.h"

static bool run;

int main (void)
{
    system_init();
	static uint16_t time;
    char str[3];

    /* TODO: Initialise the button driver, tinygl, and the pacer.  */
	button_init ();
	pacer_init(200);
	tinygl_init(200);
	tinygl_font_set (&font3x5_1);
    tinygl_text_mode_set (TINYGL_TEXT_MODE_STEP);
    tinygl_text_dir_set (TINYGL_TEXT_DIR_ROTATE);
	
	tinygl_text("00");
	while(1) {
		button_update();
		if (button_push_event_p (BUTTON1)) {
			run = !run;
		}
		while(1)
		{
			button_update();
			if (button_push_event_p (BUTTON1)) {
				run = !run;
			}
			pacer_wait();
			tinygl_update();
			
				

			if (!run)
			{
				time = 0;
				break;
			}

			str[0] = ((time / 10) % 10) + '0';
			str[1] = (time % 10) + '0';
			str[2] = 0;

			tinygl_text (str);

			time++;
			/* TODO: Implement the functionality of the tasks in the
				   stopwatch1 program.  */

		}
	}
    return 0;
}
