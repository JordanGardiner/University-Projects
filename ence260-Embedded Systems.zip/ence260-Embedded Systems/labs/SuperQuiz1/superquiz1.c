/* Code for superquiz 1
 * Written by jga99
 * Date 27-7-17
 *
 * Questions for labs
 * What does the out put need to look like?
 * how should the terminal output values? All at the end or individually?
 */

#include <stdio.h>

int main(void)
{
    int stopper = 0;
    int next_stopper = 0;
    int input = 0;
    int total =0;
    scanf("%d", &stopper);
    scanf("%d", &next_stopper);
    scanf("%d", &input);
    do {
        if (input == stopper) {
            stopper = next_stopper;
            printf("%d\n", total);
            scanf("%d", &next_stopper);
            total = 0;

        } else {
            total = total + input;
        }
    } while (scanf("%d", &input) != EOF);
    return 0;
}
