#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define BUFFER_INCREMENT 10

typedef struct time_s {
    char* day;
    char* month;
    char* year;
    char* hour;
    char* min;
    char* second;
    char* timeZone;
} Time;

typedef struct line_s {
    int type;
    int ip;
    Time* time;
    char* userAgent;
} Line;


char* strchrn(char* s, char c, int n)
{
    char* buffer = malloc(strlen(s));
    strncpy(buffer, s, strlen(s));
    int iCount = 1;
    for (int i =0; i < strlen(s); i++) {
        if (c == *buffer) {
            if (iCount == n) {
                return &s[i];
            } else {
                iCount++;
            }
        }
        buffer++;
        
    }
    return NULL;
}

//modified to be inclusive
char* extractField(char* dest, size_t n, const char* leftDelim, const char* rightDelim)
{
    int i = 0;
    if (leftDelim == NULL || rightDelim == NULL) {
        return NULL;
    } else if(leftDelim >= rightDelim) {
        return NULL;
    } else if((rightDelim - leftDelim) > n) {
        return NULL;
    } else {
        
        while (leftDelim != rightDelim) {
            
            dest[i] = *leftDelim;
            leftDelim++;
            i++;
            dest[i] = '\0';
        }
    }
    return dest;
}

bool checkDate(Time* original, const char* new) {
    Time* newTime = NULL;
    newTime->day = malloc(2);
    newTime->day = strncpy(newTime->day, new, 2);
    printf("%s",newTime->day);
    //newTime->month = strncpy(newTime->month, new, 2);
    //newTime->year = strncpy(newTime->year, new, 2);
    //newTime->day = strncpy(newTime->day, new, 2);
    //newTime->day = strncpy(newTime->day, new, 2);
    //newTime->day = strncpy(newTime->day, new, 2);
    return 0;
}





char* getLine() 
{
    char* buffer = NULL;
    int bufferSize = 0;
    int i = 0;
    int c = '\0';   
    while ((c = fgetc(stdin)) != EOF && c != '\n') {
        if (i >= bufferSize - 1) {             
            bufferSize += BUFFER_INCREMENT;    
            buffer = realloc(buffer, bufferSize);
        }
        buffer[i] = c;
        i += 1;
    }
    
    return buffer;
    
}

char* getField(char* data, char leftDelim, char rightDelim, int leftDelimNum,
                int rightDelimNum)
{
    char* left = strchrn(data, leftDelim, leftDelimNum);
    char* right = strchrn(data, rightDelim, leftDelimNum); 
    char* address = malloc(right - left);
    if (extractField(address, right - left, left, right) != NULL) {
        return address;
    }
    return left;
}

Line* createLine(char* data) 
{
    Line* newLine = malloc(sizeof(Line));
    newLine->time = malloc(sizeof(Time));
    newLine->time->day = getField(data, '[', ']', 1, 2); 
    
    return newLine;
    
    
}


void readInput(void) 
{
    
    char* line = getLine();
    int i = 0;
    
    //char firstDate[26] = {'\0'};
    
    while (line != NULL) {
        //printf("%i    %s \n", i, line);
        Time* newTime = NULL;
        puts("here");
        newTime->day = malloc(8);
        char* date = NULL;
        
        char* dateLeft = strchrn(line, '[', 1);
        char* dateRight = strchrn(line, ']', 2);
        extractField(date, 27, dateLeft, dateRight);
        printf("%s", date);
        
        char* day = NULL;
        char* dayRight = strchrn(date, '/', 1);
        extractField(day, 2, date, dayRight);
        strncpy(newTime->day, day, strlen(date));
        printf("%s",newTime->day);
        puts("\nhere");
        const char* right = strchrn(line, '-', 1);
        char field[4] = {'\0'}; 
        extractField(field, 4, line, right);


        printf("%s", field);
        int strdiff = strncmp(field, "::1", 3);
        if (strdiff == 0) {
            puts("Didd \n \n \n \n");
            
            //this is a psuedo line
            //get date
            
            
        } else {
        }
        i++;
        line = getLine();
    
            
    }
    
    
    
}

int main (void) 
{
    
    readInput();

}







