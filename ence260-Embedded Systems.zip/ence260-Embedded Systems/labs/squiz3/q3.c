#include <stdio.h>
#include <stdlib.h>
#include <string.h>



const char* strchrn(const char* s, int c, int n)
{
    char* buffer = malloc(strlen(s));
    strncpy(buffer, s, strlen(s));
    int iCount = 1;
    for (int i =0; i < strlen(s); i++) {
        if (c == *buffer) {
            if (iCount == n) {
                return &s[i];
            } else {
                iCount++;
            }
        }
        buffer++;
        
    }
    return NULL;
}


char* extractField(char* dest, size_t n, const char* leftDelim, const char* rightDelim)
{
    int i = 0;
    if (leftDelim == NULL || rightDelim == NULL) {
        return NULL;
    } else if(leftDelim >= rightDelim) {
        return NULL;
    } else if((rightDelim - leftDelim) > n) {
        return NULL;
    } else {
        leftDelim++;
        while (leftDelim != rightDelim) {
            
            dest[i] = *leftDelim;
            leftDelim++;
            i++;
            dest[i] = '\0';
        }
    }
    return dest;
}




int main (void) 
{
    const char* csvLine = "Angus McGurk,89,44 Fadges Lane,Bryndwr";
    char address[80] = {0};
    const char* left = strchrn(csvLine, ',', 2);    // 2nd comma
    const char* right = strchrn(csvLine, ',', 3);   // 3rd comma
    if (extractField(address, 80, left, right) == NULL) {
        printf("Error!\n");
    } else {
        printf("Extracted address = '%s'\n", address);
    }
}







