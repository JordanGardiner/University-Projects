#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define BUFFER_INCREMENT 10

int findMonth(char* mon) 
{
    char* months[12] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", 
                        "Aug", "Sep", "Oct", "Nov", "Dec"};
    for (int i = 0; i != 12; i++) {
        if (strcmp(mon, months[i]) == 0) {
            return i;
        }
    }
    return 13;
}
        
char* strchrn(char* s, char c, int n)
{
    char* buffer = malloc(strlen(s));
    strncpy(buffer, s, strlen(s));
    int iCount = 1;
    for (int i =0; i < strlen(s); i++) {
        if (c == *buffer) {
            if (iCount == n) {
                return &s[i];
            } else {
                iCount++;
            }
        }
        buffer++;
        
    }
    return NULL;
}

//modified to be inclusive
char* extractField(char* dest, size_t n, const char* leftDelim, const char* rightDelim)
{
    int i = 0;
    if (leftDelim == NULL || rightDelim == NULL) {
        return NULL;
    } else if(leftDelim >= rightDelim) {
        return NULL;
    } else if((rightDelim - leftDelim) > n) {
        return NULL;
    } else {
        
        while (leftDelim != rightDelim) {
            
            dest[i] = *leftDelim;
            leftDelim++;
            i++;
            dest[i] = '\0';
        }
        dest[i] = *leftDelim;
        i++;
        dest[i] = '\0';
    }
    return dest;
}





char* getLine() 
{
    char* buffer = NULL;
    int bufferSize = 0;
    int i = 0;
    int c = '\0';
    c = fgetc(stdin);
    while (c != EOF && c != '\n') {
        if (i == 4001) {
            printf("Broken");    //  ********
            break;
        }
        if (i >= bufferSize - 1) {             
            bufferSize += BUFFER_INCREMENT;    
            buffer = realloc(buffer, bufferSize +1);
        }
        buffer[i] = c;
        i += 1;
        buffer[i] = '\0';
        c = fgetc(stdin);
        
    }
    return buffer;
    
}


char* getField(char leftDelim, int occurLeft, char rightDelim,
                int occurRight, char* line, int inclus)
{
    //if inclus is 1, function is inclusive
    char* output = malloc(1);
    char* left = NULL;
    
    char* right = NULL;
    int len = 0;
    if (inclus == 1) {
            
        left = strchrn(line, leftDelim, occurLeft) +1;
        right = strchrn(line, rightDelim, occurRight) -1;
        strchrn(line, rightDelim, occurRight);
        len = ((right - line) - (left - line)) +1;
        output = realloc(output, len + 1);
        output = extractField(output, len, left, right);
    } else { 
        
        left = strchrn(line, leftDelim, occurLeft);
        right = strchrn(line, rightDelim, occurRight);
        strchrn(line, rightDelim, occurRight);
        len = ((right - line) - (left - line)) +1;
        output = realloc(output, len + 1);
        output = extractField(output, len, left, right);
    }
    output[len+1] = '\0';
    
    return output;
    
   
        
}

char* compTimes(char* earliest, char* newTime) 
{
    char* valueNew = NULL;
    char* valueOld = NULL;
    
    valueNew = getField('/', 2, ':', 1, newTime, 1);
    valueOld = getField('/', 2, ':', 1, earliest, 1);
    char* ret = NULL;
    if (atoi(valueNew) == atoi(valueOld)) {
        //Year
        valueNew = getField('/', 1, '/', 2, newTime, 1);
        valueOld = getField('/', 1, '/', 2, earliest, 1);
        if (findMonth(valueNew) == findMonth(valueOld)) {
            //Month
            valueNew = getField('[', 1, '/', 1, newTime, 1);
            valueOld = getField('[', 1, '/', 1, earliest, 1);
            if (atoi(valueNew) == atoi(valueOld)) {
                //day
                valueNew = getField(':', 1, ':', 2, newTime, 1);
                valueOld = getField(':', 1, ':', 2, earliest, 1);
                if (atoi(valueNew) == atoi(valueOld)) {
                    //hour
                    valueNew = getField(':', 2, ':', 3, newTime, 1);
                    valueOld = getField(':', 2, ':', 3, earliest, 1);  
                    if (atoi(valueNew) == atoi(valueOld)) {
                    //minute
                        valueNew = getField(':', 3, ' ', 1, newTime, 1);
                        valueOld = getField(':', 3, ' ', 1, earliest, 1);
                        if (atoi(valueNew) == atoi(valueOld)) {
                        //second
                            ret = earliest;
                        } else if(atoi(valueNew) < atoi(valueOld)) { 
                            ret =  newTime;
                        } else {
                            ret =  earliest;
                        }
                    } else if (atoi(valueNew) < atoi(valueOld)) {
                        ret =  newTime;
                    } else { 
                        ret =  earliest;
                    }
                } else if (atoi(valueNew) < atoi(valueOld)) {
                    ret =  newTime;
                } else {
                    ret =  earliest;
                }
            } else if (atoi(valueNew) < atoi(valueOld)) {
                ret =  newTime;
            } else {
                ret =  earliest;
            }
        } else if (findMonth(valueNew) < findMonth(valueOld)) {
            ret =  newTime;
        } else {
            ret =  earliest;
        }
    } else if (atoi(valueNew) < atoi(valueOld)) {
        ret =  newTime;
    } else { 
        ret =  earliest;
    }
    ret[29] = '\0';
    return ret;
    
}

void readInput(void) 
{
    
    char* line = getLine();
    int i = 0;
   // char* agentField = NULL;
    char* earliest = malloc(29);
    char* latest = malloc(29);
    char* hold = malloc(29);
    earliest[29] = '\0';
    latest[29] = '\0';
    hold[29] = '\0';
    int externalAccess = 0;
    //int robotAccess = 0;
    
    
    
    char* date = NULL;
    while (line != NULL) {
        date = getField('[', 1, ']', 1, line, 0);
        if (i == 0) {   
            strncpy(earliest, date, strlen(date));
            strncpy(latest, date, strlen(date));
            
        } else {
            strncpy(earliest, compTimes(earliest, date), strlen(date));
            //if (strcmp(earliest, date) != 0) {
                //compare for the smallest of date and latest
         //       strncpy(hold, compTimes(latest, date), strlen(date));
          //      if (strcmp(hold, date) != 0) {
         //           strncpy(latest, date, strlen(date));
         //       }
        //    } 
                
        }

       if (strcasestr(line, "::1") == NULL) {
            //not a psuedo line
            externalAccess += 1;   
        }            
       
        //agentField = getField('"', 5, '"', 6, line, 1);
       // if (strcasestr(agentField, "bot") != NULL) {
    //        robotAccess++;
   //     }
  
        i++;
        line = getLine();
        
     
            
    }
  //  printf("\n%s : is the earliest\n", earliest);
 //   printf("\n%s : is the latest\n", latest);
 //   printf("\n%i : external access\n", externalAccess);
 //   printf("\n%i : robot access\n", robotAccess);
 //   free(earliest);
 //   free(latest);
//free(hold);
    
}

int main (void) 
{
    readInput();
    
}







