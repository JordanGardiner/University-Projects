#include <stdio.h>
#include <stdlib.h>
#include <string.h>

const char* strchrn(const char* s, char c, int n)
{
    char* buffer = malloc(strlen(s));
    strncpy(buffer, s, strlen(s));
    int iCount = 1;
    for (int i =0; i < strlen(s); i++) {
        if (c == *buffer) {
            if (iCount == n) {
                return &s[i];
            } else {
                iCount++;
            }
        }
        buffer++;
        
    }
    return NULL;
}


int main (void) 
{
    char* line = "This is a string";
    for (int n = 1; n <= 5; n++) {
        const char* ptr = strchrn(line, 'i', n);
        if (ptr != NULL) {
            int index = ptr - line;
            printf("Occurrence %d of 'i' found at index = %d\n", n, index);
        } else {
             printf("Occurrence %d of 'i' not found\n", n);
        }
}   
    
    
    
}

