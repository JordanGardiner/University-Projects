#include <avr/io.h>
#include "system.h"
#include "led.h"


int main (void)
{
    system_init ();
    led_init ();
    
    
    /* TODO: Initialise timer/counter1.  */
    
    TCCR1A = 0x00; 
    
    TCCR1B = 0x05;
    
    TCCR1C = 0x00;
   
    //  The above code will tell the AVR microprocessor to divide the main 8 MHz
    //  clock by 1024 for Timer/Counter1. This is performed by placing 0x05 in
    //  TCCR1B
    
    
    while (1)
    {
        
        /* Turn LED on.  */
        led_set (LED1, 1);
        
        TCNT1 = 0x00;
        
        while (TCNT1 < 3906){
			
		}
		
        /* TODO: wait for 500 milliseconds.  */
        
        /* Turn LED off.  */
        led_set (LED1, 0);
        
        TCNT1 = 0x00;
        while (TCNT1 < 3906*4){
			
		}
        /* TODO: wait for 500 milliseconds.  */
        
    }
    
}
