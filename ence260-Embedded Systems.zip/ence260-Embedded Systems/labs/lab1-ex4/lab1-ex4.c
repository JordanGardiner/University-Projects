#include "button.h"
#include "led.h"
#include "system.h"


int main (void)
{
    system_init ();

    led_init ();
    button_init ();
	int pressed = 0;
    while (1)
    {
        if (button_pressed_p())
        {
			if (pressed) {
				led_off();
				pressed = 0;
			} else {
				led_on ();
				pressed = 1;
			}
        }
        //else// if (pressed == 0)
        //{
        //    led_off ();
        //}
    }
}
