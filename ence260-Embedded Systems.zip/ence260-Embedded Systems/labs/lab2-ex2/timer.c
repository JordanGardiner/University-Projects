#include <avr/io.h>
#include "timer.h"

/* Initialise timer.  */
void timer_init (void)
{
    /* TODO */
        
    TCCR1A = 0x00; 
    
    TCCR1B = 5;
    
    TCCR1C = 0x00;
    
    //  The above code will tell the AVR microprocessor to divide the main 8 MHz
    //  clock by 1024 for Timer/Counter1. This is performed by placing 0x05 in
    //  TCCR1B
    
}


/* Wait for the specified length of time.  */
void timer_delay_ms (uint16_t milliseconds)
{
    /* TODO: Calculate the timer/counter value needed 
       for the given number of milliseconds. */
        TCNT1 = 0x00;
        milliseconds = (milliseconds* 0.001) /0.000128;
        
        while (TCNT1 < milliseconds){
			
		}
    /* TODO: Wait for the timer/couter to reach the 
       value calculated above.  */
}
