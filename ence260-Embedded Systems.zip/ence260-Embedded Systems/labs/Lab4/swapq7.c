#include <stdio.h>

void swap(int* pi, int* pj)
{
    int hold = *pi;
    *pi = *pj;
    *pj = hold;

}

int main(void)
{
	int i = 300;
	int j = 7;
	
	swap(&i, &j);
	printf("%d, %d", i, j);
	
}
