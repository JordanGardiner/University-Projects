#include <stdio.h>


char* mystrrchr(char* s, int c)
{
    char* last = NULL;
    for(int i = 0; s[0] != '\0'; i++) {
        if (s[0] == c) {
            last = s;
        }
        s++;
    }
    return last;
}


int main(void)
{
	char* s = "ENCE260";
	char* foundAt = mystrrchr(s, 'E');
	if (foundAt == NULL) {
		puts("Not found");
	}
	else {
		printf("%zu\n", foundAt - s);
	}
}
