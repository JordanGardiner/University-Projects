#include <stdio.h>

int main(void)
{
	int i = 0;
    char* s = "Ummm: ";
    while (*s) {
        printf("%c ", s[i]);
        s++;
        
    }
    printf("s[0] = %c", s[0]);
}
