#include <stdio.h>



void printViaPtr(int* ptr) 
{
	printf("%d", *ptr);
}

void print2Ints(int i, int j)
{
	int* ptr1 = NULL;
	ptr1 = &i;
	int* ptr2 = NULL;
	ptr2 = &j;
	printViaPtr(ptr1);
	printViaPtr(ptr2);
}



int main(void)
{
	print2Ints(1, 2);
}
