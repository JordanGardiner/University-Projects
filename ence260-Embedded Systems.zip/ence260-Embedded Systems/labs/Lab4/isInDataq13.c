#include <stdio.h>
#include <stdbool.h>

char data[99] = {0};

bool isInData(char* p)
{

    char* topAdrData = &data[99];
    char* btmAdrData = &data[0];
    if(p <= topAdrData) {
        if(p >= btmAdrData) {
            return 1;
        } else {
            return 0;
        }
    } else {
        return 0;
    }
}

int main(void)
{

	printf("%d\n", isInData(&data[0]));
	printf("%d\n", isInData(&data[17]));
	printf("%d\n", isInData(&data[99]));
	int numInside = 0;
	for (int i = -100; i <= 200; i++) {
		if (isInData(&data[i])) {
			printf(" %i", i);
			numInside += 1;
		}
	}

	printf("%d values were within data array\n", numInside);
		
	int numInside1 = 0;
	for (int i = 1; i <= 99; i++) {
		if (isInData(&data[i])) {
			numInside1 += 1;
		}
	}

	printf("%d values were within data array\n", numInside1);
}

