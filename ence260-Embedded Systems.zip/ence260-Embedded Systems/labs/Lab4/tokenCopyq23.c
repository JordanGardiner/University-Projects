#include <stdio.h>



int tokenCopy(char* dest, const char* src, int destSize)
{
	int i;
	for(i = 0;i <= destSize; i++) {
		*dest = *src;
		src++;
		dest++;
		i++;
	}
	
	return i-1;
	
}






int main(void)
{
	char buff[5];
	int n = tokenCopy(buff, "This is a string", 5);
	printf("%d '%s'\n", n, buff);
	
	
}
