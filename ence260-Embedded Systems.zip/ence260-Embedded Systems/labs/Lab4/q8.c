#include <stdio.h>

void oof(char* p1, char* p2)
{
    *p1 = *p2;

 
}

void blah()
{
    char c = 'X';
    char other = 'Y';
    oof(&other,  &c);

    printf("%c\n", other);
}


int main(void)
{
	blah();
	
}
