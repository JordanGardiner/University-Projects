#include "pio.h"
#include "system.h"
#include "pacer.h"

int main (void)
{
    system_init ();
	pio_config_set(LEDMAT_ROW1_PIO, PIO_OUTPUT_LOW);
	pio_config_set(LEDMAT_COL1_PIO, PIO_OUTPUT_LOW);
	
	pio_config_set(LEDMAT_ROW2_PIO, PIO_OUTPUT_LOW);
	pio_config_set(LEDMAT_COL2_PIO, PIO_OUTPUT_LOW);
	pio_config_set(LEDMAT_ROW3_PIO, PIO_OUTPUT_LOW);
	pio_config_set(LEDMAT_COL3_PIO, PIO_OUTPUT_LOW);
	pio_config_set(LEDMAT_ROW4_PIO, PIO_OUTPUT_LOW);
	pio_config_set(LEDMAT_COL4_PIO, PIO_OUTPUT_LOW);
	pio_config_set(LEDMAT_ROW5_PIO, PIO_OUTPUT_LOW);
	pio_config_set(LEDMAT_COL5_PIO, PIO_OUTPUT_LOW);
	pio_config_set(LEDMAT_ROW6_PIO, PIO_OUTPUT_LOW);
	pio_config_set(LEDMAT_ROW7_PIO, PIO_OUTPUT_LOW);
	
    while (1)
    {
	//	pacer_wait();
		
        /* TODO.  Use PIO module to turn on LEDs in
           LED matrix.  */
		pio_output_low(LEDMAT_ROW1_PIO);
		pio_output_low(LEDMAT_ROW2_PIO);
		pio_output_low(LEDMAT_ROW3_PIO);
		pio_output_low(LEDMAT_ROW4_PIO);
		pio_output_low(LEDMAT_ROW5_PIO);
		pio_output_low(LEDMAT_ROW6_PIO);
		pio_output_low(LEDMAT_ROW7_PIO);
		pio_output_low(LEDMAT_COL5_PIO);
		
		pio_output_high(LEDMAT_COL1_PIO);
		pio_output_high(LEDMAT_COL2_PIO);
		pio_output_high(LEDMAT_COL3_PIO);
		pio_output_high(LEDMAT_COL4_PIO);
		
	//	pacer_wait();
		
		pio_output_high(LEDMAT_ROW1_PIO);
		pio_output_high(LEDMAT_ROW2_PIO);
		pio_output_high(LEDMAT_ROW3_PIO);
		pio_output_high(LEDMAT_ROW4_PIO);
		pio_output_high(LEDMAT_ROW5_PIO);
		pio_output_high(LEDMAT_ROW6_PIO);
		pio_output_high(LEDMAT_ROW7_PIO);
		pio_output_high(LEDMAT_COL5_PIO);
		
		
		pio_output_low(LEDMAT_ROW1_PIO);
		pio_output_low(LEDMAT_COL4_PIO);
		pio_output_low(LEDMAT_ROW2_PIO);
		pio_output_low(LEDMAT_COL1_PIO);
		pio_output_low(LEDMAT_COL2_PIO);
		pio_output_low(LEDMAT_COL3_PIO);
		pio_output_low(LEDMAT_ROW6_PIO);
		pio_output_low(LEDMAT_ROW7_PIO);
		
		
    }
}
