#ifndef DECISION_H
#define DECISION_H

/**
 * Find winner.
 * 
 * @param playerOne character selected by playerOne
 * @param playerTwo character selected by playerTwo
 * @return int 0 if playerOne loses, 1 if playerOne wins, 2 if draw.
 **/
int findWinner(char playerOne, char playerTwo);

#endif
