/** 
 * Author: Cameron Henderson (che121), Jordan Gardiner (jga99)
 * Date: 11/10/2017
 * 
 * Decision module for deciding the winner of the game.
 **/

/**
 * Find winner.
 * 
 * @param player_one character selected by player_one
 * @param player_two character selected by player_two
 * @return int 0 if player_one loses, 1 if player_one wins, 2 if draw.
 **/
int find_winner(char player_one, char player_two)
{
    if (player_one == player_two) {
        return 2;
        
    } else if (player_one == 'P') {
        
        if (player_two == 'R') {
            return 1;
        } else {
            return 0;
        }
        
    } else if (player_one == 'R') {
        
        if (player_two == 'P') {
            return 0;
        } else {
            return 1;
        }
        
    } else {
        
        if (player_two == 'P') {
            return 1;
        } else {
            return 0;
        }
    }
}
