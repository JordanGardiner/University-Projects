/**
 * Author: Jordan Gardiner (jga99), Cameron Henderson (che121)
 * Date: 11/10/2017
 * 
 * Functions for turning the blue LED on and off, taken from
 * lab1-ex2.
 **/
 
#include <avr/io.h>
#include "led.h"

/** Initialise port to drive LED 1.  */
void led_init (void)
{
    DDRC |= (1<<2);
}

/** Set port to turn LED 1 on.  */
void led_on (void)
{
    PORTC |= (1<<2);
}

/** Set port to turn LED 1 off.  */
void led_off (void)
{
    PORTC &= ~(1<<2);
}
