/**
 * Author: Jordan Gardiner (jga99), Cameron Henderson (che121)
 * Date: 11/10/2017
 * 
 * Runs the outer loop (so each loop is one full game.
 * Second loop displays outcome.
 **/

#include "../fonts/font5x7_1.h"
#include "system.h"
#include "tinygl.h"
#include "led.h"
#include "select.h"
#include "pacer.h"
#define DISPLAY_WAIT 3000

/**
 * Runs game through loop.
 **/
int main (void)
{
    system_init ();
    led_init();
    int output;

    while (1) {
        output = select_init();
        led_off();
        
        if (output == 1) {
            tinygl_text("WIN");
        } else if (output == 0) {
            tinygl_text("LOST");
        } else {
            tinygl_text("DRAW");
        }
        
        tinygl_text_mode_set(TINYGL_TEXT_MODE_SCROLL);
        int i = 0;
        
        while (i != DISPLAY_WAIT) {
            pacer_wait();
            tinygl_update();
            i++;
        }
    }
}
