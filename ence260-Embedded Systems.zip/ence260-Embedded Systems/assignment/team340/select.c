/**
 * Author: Jordan Gardiner (jga99), Cameron Henderson (che121)
 * Date: 11/10/2017
 * 
 * Program to track and receive input between the two funkits.
 **/

#include "ir_uart.h"
#include "tinygl.h"
#include "../fonts/font5x7_1.h"
#include "system.h"
#include "pacer.h"
#include "navswitch.h"
#include "led.h"
#include "decision.h"
#define PACER_RATE 400
#define MESSAGE_RATE 20

char opponent;
int recieved = 0;

/** 
 * Wait.
 * 
 * This function is called once the navswitch is pushed and
 * waits until the player has received data back. 
 **/
void wait(void)
{
    tinygl_text_mode_set(TINYGL_TEXT_MODE_SCROLL);
    tinygl_text(" WAIT");
    
    if (recieved == 0) {
        
        while (1) {
            
            pacer_wait();
            tinygl_update ();
            
            if (ir_uart_read_ready_p()) {
                opponent = ir_uart_getc();
                recieved = 1;
                break;
            }
            
        }
    }
}

/** 
 * Select initialisation.
 * 
 * Lets a player select a character. Uses findWinner to determine
 * who one the round.
 * 
 * @return int 0,1 or 2 indicating whether the player lost,
 * won or drew.
 **/
int select_init(void) 
{
    system_init ();
    led_init();
    ir_uart_init();
    pacer_init(PACER_RATE);
    navswitch_init ();
    
    tinygl_init (PACER_RATE);
    tinygl_font_set (&font5x7_1);
    tinygl_text_speed_set (MESSAGE_RATE);
    tinygl_clear();
    
    char character[3] = {'P', 'S', 'R'};
    int unsigned index = 1000;
    char buffer[2];

    while (1) {
        
        pacer_wait ();
        tinygl_update ();
        navswitch_update ();
        
        if (navswitch_push_event_p (NAVSWITCH_NORTH)) {
            index++;
        }
        
        if (navswitch_push_event_p (NAVSWITCH_SOUTH)) {
            index--;
        }
        
        buffer[0] = character[(index)%3];
        buffer[1] = '\0';
        tinygl_text(buffer);
        
        if (ir_uart_read_ready_p()) {
            opponent = ir_uart_getc();
            recieved = 1;
            led_on();
        }
        
        if (navswitch_push_event_p (NAVSWITCH_PUSH)) { 
            tinygl_clear();
            
            if (ir_uart_write_ready_p()) {
                ir_uart_putc(buffer[0]);
                wait();
                break;
            }
            
        }   
        
    }
    
    /*calls winner and returns 1 if self, 0 if other or 2 if draw */
    recieved = 0;
    return find_winner(buffer[0], opponent);
    
}

