#ifndef SELECT_H
#define SELECT_H

/** 
 * Select initialisation.
 * 
 * Lets a player select a character. Uses findWinner to determine
 * who one the round.
 * 
 * @return int 0,1 or 2 indicating whether the player lost,
 * won or drew.
 **/
int select_init(void);

/** 
 * Wait.
 * 
 * This function is called once the navswitch is pushed and
 * waits until the player has received data back. 
 **/
void wait(void);
#endif
