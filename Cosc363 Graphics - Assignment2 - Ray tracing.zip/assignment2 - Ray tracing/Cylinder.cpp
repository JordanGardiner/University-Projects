/*----------------------------------------------------------
* Author jga99
-------------------------------------------------------------*/

#include "Cylinder.h"
#include <math.h>
#include <cmath>


float Cylinder::intersect(glm::vec3 posn, glm::vec3 dir)
{

	float a = pow(dir.x, 2) + pow(dir.z,2);
	float b = 2 * (dir.x * (posn.x - center.x) + dir.z * (posn.z - center.z));
	float c = pow((posn.x - center.x), 2) + pow((posn.z - center.z),2) - pow(radius,2);
	
	float quadraticForm = pow(b,2) - 4*(a*c);
	
	if(quadraticForm == 0){
		return -1;
	}
	//quadratic formula
	float t = (-b - sqrt(quadraticForm)) / (2*a); 
	float t2 = (-b + sqrt(quadraticForm)) / (2*a);

	
	if(t < 0.01 )
    {
		t = -1;
	}
	if (t2 < 0.01) {
		t2 =-1;
	}

		
	//check for height
	float ySmall = posn.y + dir.y * t;
	float yLarge = posn.y + dir.y * t2;
	
	if((ySmall >= center.y) && (ySmall <= center.y + height)){
		return t;
	} else if((yLarge >= center.y) && (yLarge <= center.y + height)){
		return t2;
	} else {
		return -1;
	}
	
	}


/**
* Returns the unit normal vector at a given point.
* Assumption: The input point p lies on the sphere.
*/
glm::vec3 Cylinder::normal(glm::vec3 p)
{
    glm::vec3 n((p.x - center.x), 0, (p.z - center.z));
    n = glm::normalize(n);
    return n;
}
