/*----------------------------------------------------------
* Author jga99 & Cosc Lab 7/8
-------------------------------------------------------------*/


#include <stdio.h>
#include <iostream>
#include <cmath>
#include <vector>
#include <glm/glm.hpp>
#include "Sphere.h"
#include "SceneObject.h"
#include "Ray.h"
#include <GL/glut.h>
#include "TextureBMP.h"
#include "Plane.h"
#include "Cylinder.h"
#define _USE_MATH_DEFINES

const float WIDTH = 20.0;  
const float HEIGHT = 20.0;
const float EDIST = 40.0;
const int NUMDIV = 1500;
const int MAX_STEPS = 5;
const float XMIN = -WIDTH * 0.5;
const float XMAX =  WIDTH * 0.5;
const float YMIN = -HEIGHT * 0.5;
const float YMAX =  HEIGHT * 0.5;

TextureBMP texture;
TextureBMP texture2;

using namespace std;

vector<SceneObject*> sceneObjects;  //A global list containing pointers to objects in the scene


glm::vec3 trace(Ray ray, int step)
{
	float ETA = 1.01;
    float shinyness = 10;
    glm::vec3 backgroundCol(0);
    glm::vec3 light(10, 40, -3);
    glm::vec3 specCol = glm::vec3(0,0,0);

    glm::vec3 ambientCol(0.2);   
	glm::vec3 colorSum(0);
    ray.closestPt(sceneObjects);        

    if(ray.xindex == -1) return backgroundCol;      //If there is no intersection return background colour
    
    glm::vec3 materialCol = sceneObjects[ray.xindex]->getColor(); 
    glm::vec3 normalVector = sceneObjects[ray.xindex]->normal(ray.xpt);
    
    glm::vec3 lightVector = light - ray.xpt;
    float lightDist = glm::length(lightVector);

    lightVector = glm::normalize(lightVector);
    
    float lDotN = glm::dot(lightVector, normalVector);
    
    glm::vec3 reflVector = glm::reflect(-lightVector, normalVector);
    
    float rDotV = glm::dot(reflVector, -ray.dir);    
    
	Ray shadow(ray.xpt, lightVector);
    shadow.closestPt(sceneObjects);

     if(ray.xindex == 3){
		
		int checker1 = (int)((ray.xpt.x + 60) /6) % 2;
		int checker2 = (int)((ray.xpt.x + 200) /6) % 2;
		
		if((checker1 && checker2) || (!checker1 && !checker2)){
			materialCol = glm::vec3(0,1,1);
		} else {
			materialCol = glm::vec3(0,0,0.3);
		}
		
	} 
	if(ray.xindex == 7){
		
		int checker1 = (int)((ray.xpt.x + 60) /.5) % 2;
		int checker2 = (int)((ray.xpt.y + 200) /.5) % 2;
		
		if((checker1 && checker2) || (!checker1 && !checker2)){
			materialCol = glm::vec3(0.5,.6,1);
		} else {
			materialCol = glm::vec3(0,0,0.3);
		}
		
	} 
	
    if(rDotV >= 0) {
        specCol = pow(rDotV, shinyness) * glm::vec3(1,1,1);
    }
    if((lDotN <= 0 || shadow.xindex >-1) && (shadow.xdist < lightDist)){
        if(shadow.xindex == 2 || shadow.xindex == 4){
			colorSum += (ambientCol * materialCol) + (lDotN * materialCol + specCol) * glm::vec3(.55)+sceneObjects[shadow.xindex]->getColor()*glm::vec3(0.11);
		} else {
			colorSum = ambientCol * materialCol;
        }
    } else {
        colorSum = (ambientCol * materialCol) + (lDotN * materialCol + specCol);
    }

    
    if((ray.xindex == 1) && step < MAX_STEPS){
		glm::vec3 reflectedDir = glm::reflect(ray.dir, normalVector);
		Ray reflectedRay(ray.xpt, reflectedDir);
		glm::vec3 reflectedCol = trace(reflectedRay, step+1);
		colorSum = colorSum + (.8f*reflectedCol);
		
	}
	
	 else if(ray.xindex == 2 && step < MAX_STEPS){   //refractive sphere   
		Ray ray2(ray.xpt, ray.dir);
		ray2.closestPt(sceneObjects);
		
		if(ray2.xindex == -1){
			return backgroundCol;
		}
		
		glm::vec3 reflectedDir = glm::reflect(ray.dir, normalVector);
		Ray reflectedRay(ray.xpt, reflectedDir);
		glm::vec3 reflectedCol = trace(reflectedRay, step+1);
		colorSum = colorSum + (.3f*reflectedCol);
		
		
		glm::vec3 g = glm::refract(ray.dir, normalVector, 1.0f/ETA);
		
		Ray refractedRay1(ray.xpt, g);
		refractedRay1.closestPt(sceneObjects);
	
		
		if(ray2.xindex != 2){
			glm::vec3 refractedCol = trace(ray2, step+1);
			colorSum = (.3f*colorSum) + (.7f*refractedCol);
		} else if(refractedRay1.xindex == 2){
				
			
			glm::vec3 m = sceneObjects[refractedRay1.xindex]->normal(refractedRay1.xpt);
			
			glm::vec3 h = glm::refract(refractedRay1.dir, -m, ETA);
			
			Ray refractedRay2(refractedRay1.xpt, h);
			
			refractedRay2.closestPt(sceneObjects);
			if(refractedRay2.xindex == -1){
					return backgroundCol;
			} 
			
			glm::vec3 refractedCol = trace(refractedRay2, step+1);
			colorSum = (.3f*colorSum) + (.7f*refractedCol);
			
		} 
		
					
	} else if(ray.xindex == 4 && step < MAX_STEPS){ //transparent sphere
				glm::vec3 reflectedDir = glm::reflect(ray.dir, normalVector);
		Ray reflectedRay(ray.xpt, reflectedDir);
		glm::vec3 reflectedCol = trace(reflectedRay, step+1);
		colorSum = colorSum + (.3f*reflectedCol);
				
		Ray ray2(ray.xpt, ray.dir);
		
		ray2.closestPt(sceneObjects);
		
		if(ray2.xindex == -1){
			return backgroundCol*.8f;
		} else if(ray2.xindex == 4){
							
			Ray ray3(ray2.xpt, ray.dir);
			
			ray3.closestPt(sceneObjects);
			if(ray3.xindex == -1){
					return backgroundCol;
			}
			glm::vec3 refractedCol = trace(ray3, step+1);
			colorSum = (.3f*colorSum) + (.7f*refractedCol);
		} else {
			glm::vec3 refractedCol = trace(ray2, step+1);
			colorSum = (.3f*colorSum) + (.7f*refractedCol);
		}
				
		
	} else if(ray.xindex == 5){
		float s = (ray.xpt.x - 60)/(-60 - 60);
		float t = (ray.xpt.y - -20)/(50 - -20);
		colorSum = texture.getColorAt(s,t);
		
	} else if(ray.xindex == 6){
		
		glm::vec3 center(-15, 10.0, -80.0);
		center = ray.xpt-center;
		
		float u = (atan2(center.z, center.x)) / (2*M_PI);
		float v = ((center.y+2.5)/5);
		colorSum = texture2.getColorAt(u,v);
		
	}
    
	
	return colorSum;
    
}

void display()
{
    float xp, yp; 
    float cellX = (XMAX-XMIN)/NUMDIV;  
    float cellY = (YMAX-YMIN)/NUMDIV;  

    glm::vec3 eye(0., 0., 0.);  //The eye position (source of primary rays) is the origin

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glBegin(GL_QUADS);  //Each cell is a quad.

    for(int i = 0; i < NUMDIV; i++)     //For each grid point xp, yp
    {
        xp = XMIN + i*cellX;
        for(int j = 0; j < NUMDIV; j++)
        {
            yp = YMIN + j*cellY;

            glm::vec3 dir(xp+0.5*cellX, yp+0.5*cellY, -EDIST);  //direction of the primary ray

            Ray ray = Ray(eye, dir);        //Create a ray originating from the camera in the direction 'dir'
            ray.normalize();                //Normalize the direction of the ray to a unit vector
            glm::vec3 col = trace (ray, 1); //Trace the primary ray and get the colour value

            glColor3f(col.r, col.g, col.b);
            glVertex2f(xp, yp);             //Draw each cell with its color value
            glVertex2f(xp+cellX, yp);
            glVertex2f(xp+cellX, yp+cellY);
            glVertex2f(xp, yp+cellY);
        }
    }

    glEnd();
    glFlush();
}

void createBox(){
	
		Plane *planeBottom = new Plane (glm::vec3(-30., -19., -160),
							  glm::vec3(-20.,-19, -160),
							  glm::vec3(-20.,-19,-180),
							  glm::vec3(-30, -19, -180),
							  glm::vec3(0.5,0,0));
							  
		Plane *planeTop = new Plane (glm::vec3(-30., -9., -160),
							  glm::vec3(-20.,-9, -160),
							  glm::vec3(-20.,-9,-180),
							  glm::vec3(-30, -9, -180),
							  glm::vec3(0.5,0,0));
		
		Plane *planeLeft = new Plane (glm::vec3(-30., -9., -160),
							  glm::vec3(-30.,-9, -180),
							  glm::vec3(-30.,-19,-180),
							  glm::vec3(-30, -19, -160),
							  glm::vec3(0.5,0,0));
			
		Plane *planeRight = new Plane (glm::vec3(-20., -9., -160),
							  glm::vec3(-20.,-9, -180),
							  glm::vec3(-20.,-19,-180),
							  glm::vec3(-20, -19, -160),
							  glm::vec3(0.5,0,0));

		Plane *planeBack = new Plane (glm::vec3(-30., -9., -180),
							  glm::vec3(-20.,-9, -180),
							  glm::vec3(-20.,-19,-180),
							  glm::vec3(-30, -19, -180),
							  glm::vec3(0.5,0,0));

		Plane *planeFront = new Plane (glm::vec3(-30., -9., -160),
							  glm::vec3(-20.,-9, -160),
							  glm::vec3(-20.,-19,-160),
							  glm::vec3(-30, -19, -160),
							  glm::vec3(0.5,0,0));

	    sceneObjects.push_back(planeBottom);
	    sceneObjects.push_back(planeTop);
		sceneObjects.push_back(planeLeft);
		sceneObjects.push_back(planeRight);
		sceneObjects.push_back(planeBack);
		sceneObjects.push_back(planeFront);



	
}



void initialize()
{
	
	texture = TextureBMP((char *)"background.bmp");
	texture2 = TextureBMP((char *)"Earth.bmp");

    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(XMIN, XMAX, YMIN, YMAX);
    glClearColor(0, 0, 0, 1);

    Sphere *reflectSphere = new Sphere(glm::vec3(5.0, -5.0, -100.0), 15.0, glm::vec3(0, 0, .5)); 
    Sphere *refractSphere = new Sphere(glm::vec3(15, -12.0, -80.0), 5.0, glm::vec3(.5, 0.5, 0.5)); 
    Sphere *glassSphere = new Sphere(glm::vec3(-15, -10.0, -80.0), 5.0, glm::vec3(1, 0.5, 0)); 

	Cylinder *cil = new Cylinder(glm::vec3(-8, -20, -80), 2.5, 5, glm::vec3(.3,0,.001));
	
	Plane *floorPlane = new Plane (glm::vec3(-60., -20., -40),
							  glm::vec3(60.,-20, -40),
							  glm::vec3(60.,-20,-200),
							  glm::vec3(-60, -20, -200),
							  glm::vec3(0.0,0.5,0.5));



	Plane *backGround = new Plane (  glm::vec3(-60., -20., -200),
							  glm::vec3(60.,-20, -200),
							  glm::vec3(60.,50, -200),
							  glm::vec3(-60., 50, -200),
							  glm::vec3(1,0,0));


	Sphere *earth = new Sphere(glm::vec3(-15, 10.0, -80.0), 2.50, glm::vec3(1, 0.5, 0)); 
	Sphere *texSphere = new Sphere(glm::vec3(15, 10.0, -80.0), 2.50, glm::vec3(1, 0.5, 0)); 

	sceneObjects.push_back(cil);
    sceneObjects.push_back(reflectSphere); 
    sceneObjects.push_back(refractSphere);         
    sceneObjects.push_back(floorPlane);
	sceneObjects.push_back(glassSphere);         

    sceneObjects.push_back(backGround);
    sceneObjects.push_back(earth);
    sceneObjects.push_back(texSphere);

    createBox();

}



int main(int argc, char *argv[]) {
    
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB );
    glutInitWindowSize(600, 600);
    glutInitWindowPosition(20, 20);
    glutCreateWindow("MyRaytracer");
   
    glutDisplayFunc(display);
    initialize();

    glutMainLoop();
    return 0;
}
