/*----------------------------------------------------------
*Cylinder
* Author jga99
-------------------------------------------------------------*/

#ifndef H_CYLINDER
#define H_CYLINDER

#include <glm/glm.hpp>
#include "SceneObject.h"


class Cylinder : public SceneObject
{
private:

    glm::vec3 center;
    float radius;
    float height;

public:	
	Cylinder(void){

        color = glm::vec3(1);
    };
	
    Cylinder(glm::vec3 c, float r, float h, glm::vec3 col)
		: center(c), radius(r), height(h) //this defines priv vars
	{
		color = col;
	};

	bool isInside(glm::vec3 pt);
	
	float intersect(glm::vec3 posn, glm::vec3 dir);
	
	glm::vec3 normal(glm::vec3 pt);

};

#endif //!H_CYLINDER
